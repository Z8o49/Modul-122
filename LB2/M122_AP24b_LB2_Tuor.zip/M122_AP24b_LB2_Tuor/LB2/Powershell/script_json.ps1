# JSON-Konfiguration einlesen
$config = Get-Content -Path "../Konfigurationen/config.json" | ConvertFrom-Json
Write-Host "URL: $($config.url)"
Write-Host "Port: $($config.port)"
