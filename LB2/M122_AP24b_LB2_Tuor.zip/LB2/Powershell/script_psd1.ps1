# Importieren der PowerShell-Daten-Datei
$config = Import-PowerShellDataFile -Path "../Konfigurationen/config.psd1"
Write-Host "URL: $($config.url)"
Write-Host "Port: $($config.port)"
