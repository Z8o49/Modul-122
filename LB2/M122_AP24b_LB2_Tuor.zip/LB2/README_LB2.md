Für LB2 habe ich ein PowerShell-Projekt erstellt, das zeigt, wie man Konfigurationsdaten vom Skriptcode trennt. Ziel war es, Werte wie URLs und Ports nicht direkt im Skript zu speichern, 
sondern aus externen Dateien zu laden. Dazu habe ich zwei PowerShell-Skripte geschrieben. Das erste Skript liest eine JSON-Datei (`config.json`) ein, 
in der die Konfigurationsdaten gespeichert sind. Das zweite Skript verwendet eine PowerShell-Daten-Datei (`config.psd1`) mit denselben Informationen.
Beide Skripte geben die geladenen Werte (URL und Port) in der Konsole aus. Die Verwendung externer Konfigurationsdateien macht den Code flexibler und leichter wartbar. 
Ich habe auch eine kurze Dokumentation erstellt, die erklärt, wie die Skripte funktionieren, und einen Vergleich der Methoden enthält.

Im Hintergrund passiert Folgendes:  
Das Skript `script_json.ps1` lädt mit `Get-Content` den Inhalt der Datei `config.json` und wandelt diesen mit `ConvertFrom-Json` in ein PowerShell-Objekt um. So kann man direkt auf die Eigenschaften `url` und `port` zugreifen.  
Beim zweiten Skript (`script_psd1.ps1`) wird `Import-PowerShellDataFile` verwendet, um die `.psd1`-Datei direkt als Hashtable zu laden.  
Diese Technik ist besonders in PowerShell üblich, da sie native Unterstützung bietet.  
Beide Methoden demonstrieren, wie man Konfigurationsdaten vom Skript trennt und dadurch flexiblen, wartbaren Code erhält.
